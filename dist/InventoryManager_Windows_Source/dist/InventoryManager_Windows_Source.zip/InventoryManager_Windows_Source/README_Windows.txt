Double-click inventorygui.py or run 'python inventorygui.py'
